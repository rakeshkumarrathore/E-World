package com.ecom.service;

import java.util.List;

import com.ecom.model.Category;

public interface CategoryService {
	
	public static Category saveCategery(Category category) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Boolean existCategory(String name);
	
	public List<Category> getALLCategory();
	
	
}
