package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller(value = "/")
public class MyController {
 
	@RequestMapping(value="")
	public String home()
	{
		
		return "home";
	}
@RequestMapping
(value="/index")
	
	public String index()
	{
		
		return "index";
	}
@RequestMapping
(value="/login")

public String login()
{

return "login";
}
@RequestMapping
(value="/registration")

public String registration()
{
return "registration";
}
@RequestMapping
(value="/product")

public String product()
{
return "product";
}
}
